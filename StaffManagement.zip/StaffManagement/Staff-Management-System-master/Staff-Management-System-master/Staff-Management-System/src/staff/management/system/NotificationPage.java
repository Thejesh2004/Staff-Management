package staff.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

class NotificationPage extends JFrame implements ActionListener {

    JTextArea messageArea;
    JButton sendButton;
    String empId;

    NotificationPage(String empId) {
        this.empId = empId;

        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Compose Message");
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);

        messageArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(messageArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        sendButton = new JButton("Send");
        sendButton.addActionListener(this);
        panel.add(sendButton, BorderLayout.SOUTH);

        add(panel, BorderLayout.CENTER);

        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == sendButton) {
            String message = messageArea.getText().trim();
            if (!message.isEmpty()) {
                saveNotification(message);
                JOptionPane.showMessageDialog(this, "Notification sent successfully!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Message cannot be empty!");
            }
        }
    }

   private void saveNotification(String message) {
    try {
        Conn connection = new Conn(); // Create a new instance of Conn class
        String query = "INSERT INTO notifications (recipient, message) VALUES (?, ?)";
        PreparedStatement preparedStatement = connection.c.prepareStatement(query);
        preparedStatement.setString(1, empId);
        preparedStatement.setString(2, message);
        preparedStatement.executeUpdate();
        JOptionPane.showMessageDialog(this, "Notification saved successfully!");
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to save notification!");
    }
}
   
}