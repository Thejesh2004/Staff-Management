package staff.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Random;

public class AttendancePage extends JFrame implements ActionListener {

    JTextField empIdField;
    JButton markPresentButton;
    JButton markAbsentButton;
    JButton salaryDetailsButton;

    AttendancePage() {
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Mark Attendance");
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(1, 2, 10, 10));

        JLabel empIdLabel = new JLabel("Employee ID:");
        empIdLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        empIdField = new JTextField();
        formPanel.add(empIdLabel);
        formPanel.add(empIdField);

        panel.add(formPanel, BorderLayout.CENTER);

        markPresentButton = new JButton("Mark Present");
        markPresentButton.addActionListener(this);
        panel.add(markPresentButton, BorderLayout.WEST);
        
        markAbsentButton = new JButton("Mark Absent");
        markAbsentButton.addActionListener(this);
        panel.add(markAbsentButton, BorderLayout.EAST);

        salaryDetailsButton = new JButton("Salary Details");
        salaryDetailsButton.addActionListener(this);
        panel.add(salaryDetailsButton, BorderLayout.SOUTH);

        add(panel, BorderLayout.CENTER);

        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == markPresentButton) {
            String empId = empIdField.getText().trim();
            if (!empId.isEmpty()) {
                markAttendance(empId, "Present");
            } else {
                JOptionPane.showMessageDialog(this, "Employee ID cannot be empty!");
            }
        } else if (e.getSource() == markAbsentButton) {
            String empId = empIdField.getText().trim();
            if (!empId.isEmpty()) {
                markAttendance(empId, "Absent");
            } else {
                JOptionPane.showMessageDialog(this, "Employee ID cannot be empty!");
            }
        } else if (e.getSource() == salaryDetailsButton) {
            // Fetch staff details from the database and display a random salary deduction message
            displaySalaryDetails();
        }
    }

    private void markAttendance(String empId, String attendanceStatus) {
        try {
            Conn connection = new Conn(); // Replace 'Conn' with your actual database connection class
            String query = "INSERT INTO attendance (empId, date, attendance) VALUES (?, CURDATE(), ?)";
            PreparedStatement preparedStatement = connection.c.prepareStatement(query);
            preparedStatement.setString(1, empId);
            preparedStatement.setString(2, attendanceStatus);
            preparedStatement.executeUpdate();

            String message;
            if (attendanceStatus.equals("Absent")) {
                message = "Your attendance has been marked as Absent.";
            } else {
                message = "Your attendance has been marked as Present.";
            }

            // Retrieve attendance data from the database and show a message based on the attendance status
            String attendanceMessage = getAttendanceMessage(empId);
            message += "\n" + attendanceMessage;

            JOptionPane.showMessageDialog(this, message);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to mark attendance!");
        }
    }

    private String getAttendanceMessage(String empId) {
        try {
            Conn connection = new Conn(); // Replace 'Conn' with your actual database connection class
            String query = "SELECT COUNT(*) FROM attendance WHERE empId = ? AND attendance = 'Present'";
            PreparedStatement preparedStatement = connection.c.prepareStatement(query);
            preparedStatement.setString(1, empId);
            ResultSet resultSet = preparedStatement.executeQuery();
            resultSet.next();
            int presentCount = resultSet.getInt(1);

            if (presentCount > 0) {
                return "You have attended " + presentCount + " days out of " + presentCount + " days.";
            } else {
                return "You have not attended any days.";
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return "Failed to retrieve attendance data.";
        }
    }

    private void displaySalaryDetails() {
        try {
            Conn connection = new Conn(); // Replace 'Conn' with your actual database connection class
            String query = "SELECT name FROM staff"; // Assuming 'empName' is the column name for staff names
            PreparedStatement preparedStatement = connection.c.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            StringBuilder message = new StringBuilder();
            Random random = new Random();
            while (resultSet.next()) {
                String empName = resultSet.getString("name");
                int deductionAmount = random.nextInt(50000) + 10000; // Generate a random deduction amount
                message.append(empName).append(": Salary deducted by ").append(deductionAmount).append("\n");
            }

            JOptionPane.showMessageDialog(this, message.toString(), "Salary Details", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to retrieve salary details.");
        }
    }

    public static void main(String[] args) {
        new AttendancePage();
    }
}
