package staff.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Home extends JFrame implements ActionListener {

    JButton view, add, update, remove, notification, attendance;

    Home() {
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/home.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1120, 630, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 1120, 630);
        add(image);

        JLabel heading = new JLabel("Staff Management System");
        heading.setBounds(620, 20, 400, 40);
        heading.setFont(new Font("Raleway", Font.BOLD, 25));
        image.add(heading);

        add = new JButton("Add Staff");
        add.setBounds(650, 80, 150, 40);
        add.addActionListener(this);
        image.add(add);

        view = new JButton("View Staff");
        view.setBounds(820, 80, 150, 40);
        view.addActionListener(this);
        image.add(view);

        update = new JButton("Update Staff");
        update.setBounds(650, 140, 150, 40);
        update.addActionListener(this);
        image.add(update);

        remove = new JButton("Remove Staff");
        remove.setBounds(820, 140, 150, 40);
        remove.addActionListener(this);
        image.add(remove);

        notification = new JButton("Send Notification");
        notification.setBounds(650, 200, 150, 40);
        notification.addActionListener(this);
        image.add(notification);

        attendance = new JButton("Manage Attendance");
        attendance.setBounds(820, 200, 150, 40);
        attendance.addActionListener(this);
        image.add(attendance);

        setSize(1120, 630);
        setLocation(250, 100);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == add) {
            setVisible(false);
            new AddStaff();
        } else if (ae.getSource() == view) {
            setVisible(false);
            new ViewStaff();
        } else if (ae.getSource() == update) {
            setVisible(false);
            new ViewStaff();
        } else if (ae.getSource() == remove) {
            setVisible(false);
            new RemoveStaff();
        } else if (ae.getSource() == notification) {
            String empId = JOptionPane.showInputDialog(this, "Enter Employee ID:");
            if (empId != null && !empId.isEmpty()) {
                new NotificationPage(empId);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Employee ID!");
            }
        } else if (ae.getSource() == attendance) {
            setVisible(false);
            new AttendancePage(); // Redirect to the AttendancePage
        }
    }

    public static void main(String[] args) {
        new Home();
    }
}
